package com.nicolaspena.hellooot

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class IoTControlActivity : AppCompatActivity() {
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_iot_control)

        // Referencia a la base de datos IoT
        database = Firebase.database.reference

        val sensorTextView = findViewById<TextView>(R.id.sensorDataTextView)
        val actionButton = findViewById<Button>(R.id.activateDeviceButton)

        // Escuchar datos del sensor en tiempo real
        database.child("dispositivos_iot").child("sensor_temperatura")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val temp = snapshot.getValue(Double::class.java)
                    sensorTextView.text = "Temperatura actual: $temp °C"
                }

                override fun onCancelled(error: DatabaseError) {
                    sensorTextView.text = "Error de lectura segura"
                }
            })

        // Enviar instrucción al actuador
        actionButton.setOnClickListener {
            database.child("dispositivos_iot").child("actuador_estado").setValue(true)
        }
    }
}
